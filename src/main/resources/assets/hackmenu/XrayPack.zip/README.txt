Hidden: stone, granite, diorite, andesite, deepslate, tuff, calcite, netherrack, basalt, blackstone, end_stone, dirt, cobblestone.
NOT hidden: water, lava, gravel, sand, magma, bedrock, etc.
Ores always visible (even behind blocks).
